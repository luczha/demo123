﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Data.SqlClient;

namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class siparis : ContentPage
    {
        public static double _adet;
        public static string neistendi, onay;
        

        View Element;

        public siparis(View element)
        {
            Element = element;
            InitializeComponent();
            yarim.Clicked += Yarim_Clicked;
            adet2.Clicked += Adet2_Clicked;
            adet3.Clicked += Adet3_Clicked;
            adet4.Clicked += Adet4_Clicked;
            adet5.Clicked += Adet5_Clicked;
            ekle.Clicked += Ekle_Clicked;
            cikar.Clicked += Cikar_Clicked;
            siparisver.Clicked += Siparisver_Clicked;
        }

        private void Cikar_Clicked(object sender, EventArgs e)
        {
            _adet = _adet - 1;
            adetsayac.Text = _adet.ToString();
        }

        private void Ekle_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 1;
            adetsayac.Text = _adet.ToString();
        }

        private void Adet5_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 5;
            adetsayac.Text = _adet.ToString();
        }

        private void Adet4_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 4;
            adetsayac.Text = _adet.ToString();
        }

        private void Adet3_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 3;
            adetsayac.Text = _adet.ToString();
        }

        private void Adet2_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 2;
            adetsayac.Text = _adet.ToString();
        }

        private void Yarim_Clicked(object sender, EventArgs e)
        {
            _adet = _adet + 0.5;
            adetsayac.Text = _adet.ToString();
        }





        //when we click that we have to make the right desk number button color to red.
        public void Siparisver_Clicked(object sender, EventArgs e)
        {
            
            

            
            //string fiyat = Convert.ToString( Convert.ToDouble(icerik.fiyat) * _adet);
            //SqlCommand siparisver = new SqlCommand("insert into siparisler (siparis,adet,garson,masano,mesaj,konum,fiyat) values ('" + icerik.verilensiparis + "' , '"+_adet.ToString()+"' , '"+MainPage.kullaniciadi+"' , '"+masterpage.secilenmasa+"' , '"+not.Text+"' , '"+masterpage.secilenkonum+"' , '"+fiyat+"')", baglanti) ;
            //siparisver.BeginExecuteNonQuery();
            
            _adet = 0;
            onay = "true";
            
            


            
                MessagingCenter.Send<siparis, View>(this, "click", Element);
                Navigation.PopToRootAsync();

            

            //if (masterpage.secilenkonum == "Alt Kat")
            //{
            //    MessagingCenter.Send<siparis>(this, "click");
            //}
            //if (masterpage.secilenkonum == "Teras")
            //{
            //    MessagingCenter.Send<siparis>(this, "click");
            //}
            //if (masterpage.secilenkonum == "Üst Kat")
            //{
            //    MessagingCenter.Send<siparis>(this, "click");
            //}
            //if (masterpage.secilenkonum == "Bahçe")
            //{
            //    MessagingCenter.Send<siparis>(this, "click");
            //}


        }


    }
}
