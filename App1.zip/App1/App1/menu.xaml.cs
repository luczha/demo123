﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Data.SqlClient;
namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class menu : ContentPage
    {
        public static string butonadi;
        public static int i;

        View Element;

      
        public menu(View element)
        {
            InitializeComponent();

            Element = element;
            //  SqlConnection baglanti = new SqlConnection(@"server=192.168.1.23,1433\SQLExpress;Database=project1;user=admin;password=root");

            //baglanti.Close();
            //int butonsayisi =-1;
            //{
            //    SqlCommand cmd = new SqlCommand("select count(*) from butonlar", baglanti);
            //    baglanti.Open();
            //    butonsayisi = Convert.ToInt32(cmd.ExecuteScalar())+1;
            //    baglanti.Close();
            //}
            //baglanti.Close();
            for (int i = 1; i < 6; i++)
            {
                
                var buttonmenu = new Button
                {

                    HeightRequest = 100,
                    WidthRequest = 100,
                    Margin = 5,
                    CornerRadius = 15,
                    BackgroundColor = Color.FromRgb(192,192,192),
                    
                };
              //  baglanti.Close();
                buttonmenu.Clicked += butonmenu;
            butonlar.Children.Add(buttonmenu);
               
                
                //just for giving a text to buttons
                buttonmenu.Text = i.ToString();
                    
                    

                async void butonmenu(object o, EventArgs args)
                 {
 
                        await Navigation.PushAsync(new icerik(element));

                }
                
        }
    }
    }
}

