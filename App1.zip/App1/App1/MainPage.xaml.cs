﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Data.SqlClient;

namespace App1
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        public static string kullaniciadi, sifre;

        //uzak sunucuya veritabanı bağlantısı 
        


        async void onclik(object o, EventArgs args)
        {
            
            
                
                
                    await Navigation.PushModalAsync(new NavigationPage(new masterpage()));


                
                

            }


        }


    }

