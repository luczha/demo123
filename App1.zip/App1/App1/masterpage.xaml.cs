﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Data.SqlClient;

namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class masterpage : TabbedPage
    {
        public static string secilenmasa,secilenkonum;
        public masterpage()
        {
            InitializeComponent();

            
           
            for (int i = 1; i < 10; i++)
            {

                var buttonteras = new Button
                {

                    Text = i.ToString(),
                    HeightRequest = 45,
                    WidthRequest = 45,
                    Margin = 5,
                    CornerRadius = 100,
                };
                buttonteras.Clicked += butonteras;
                teras.Children.Add(buttonteras);




                async void butonteras(object o, EventArgs args)
                {
                    var button = o as Button;

                    secilenmasa = buttonteras.Text;
                    secilenkonum = "Üst kat";
                    await Navigation.PushAsync(new menu(button));

                }




            }
            //buton bahçe işlemleri
            for (int k = 1; k < 10; k++)
            {
                var buttonbahce = new Button
                {
                    Text = k.ToString(),
                    HeightRequest = 45,
                    WidthRequest = 45,
                    Margin = 5,
                    CornerRadius = 100,
                };
                buttonbahce.Clicked += bahcebuton;
                bahce.Children.Add(buttonbahce);

               

                async void bahcebuton(object o, EventArgs args)
                {
                    var button = o as Button;
                    secilenmasa = buttonbahce.Text;
                    secilenkonum = "Bahçe";
                 
                    await Navigation.PushAsync(new menu(button));


                }


            }

            //the code we tried
            MessagingCenter.Subscribe<siparis, View>(this, "click", (obj, view) =>
            {
                var childrens = bahce.Children;

                for (int i = 0; i < childrens.Count; i++)
                {

                    var element = childrens[i];
                    var type = element.GetType();
                    if (element == view)
                    {
                        element.BackgroundColor = Color.Red;


                    }
                }

            });

            //buton üst kat işlemleri
            for (int l = 1; l < 10; l++)
            {
                var buttonustkat = new Button
                {
                    Text = l.ToString(),
                    HeightRequest = 45,
                    WidthRequest = 45,
                    Margin = 5,
                    CornerRadius = 100,
                };
                buttonustkat.Clicked += ustkatbuton;
                ustkat.Children.Add(buttonustkat);
            

            async void ustkatbuton(object o, EventArgs args)
                {
                    var button = o as Button;
                    secilenmasa = buttonustkat.Text;
                    secilenkonum = "Üst kat";

                    await Navigation.PushAsync(new menu(button));


                }

            }




            //altkat işlemler
            for (int j = 1; j < 10; j++)
            {
                var buttonaltkat = new Button
                {
                    Text = j.ToString(),
                    HeightRequest = 45,
                    WidthRequest = 45,
                    Margin = 5,
                    CornerRadius = 100,


                };
                buttonaltkat.Clicked += altkatbuton;

                altkat.Children.Add(buttonaltkat);
            
                //tıklanan butonun numarasını alma -- bu sayede siparişlerin girileceği id yi ayarlayacağız
                async void altkatbuton(object o, EventArgs args)
                {
                    var button = o as Button;

                    secilenmasa = buttonaltkat.Text;
                    secilenkonum = "Alt kat";
                    string sayi = buttonaltkat.Text;
                    await Navigation.PushAsync(new menu(button));


                }

            }
        }
    }
}



