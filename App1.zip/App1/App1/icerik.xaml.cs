﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Data.SqlClient;

namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class icerik : ContentPage
    {
        public static string verilensiparis, tatli,fiyat;
        public static int i;

        View Element;

        

        public icerik(View element)
        {
            InitializeComponent();

            Element = element;

            string secinlenbuton = menu.butonadi;
            int butonsayisi = 10;
            

            for (i = 1; i < butonsayisi; i++)
            {
             

                var butonicerik = new Button
                {

                    HeightRequest = 50,
                    WidthRequest = 100,
                    Margin = 5,
                    CornerRadius = 15,
                    BackgroundColor = Color.FromRgb(192, 192, 192),

                };
                butonicerik.Clicked += butonsiparis;
                icerikler.Children.Add(butonicerik);
                
                
                
                butonicerik.Text = i.ToString();
                    
                    
                


                async void butonsiparis(object o, EventArgs args)
                {

                        await Navigation.PushAsync(new siparis(element));

                }

            }
        }
    }

}


